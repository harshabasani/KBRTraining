import java.util.*;
import java.lang.*;
class Lift implements LiftOperations
{
  public void menu()
  {
   
   System.out.println("(1) For lift arrival PRESS 1");
   System.out.println("(2) For Destination PRESS 2");
   System.out.println("(3) For fan PRESS 3");
   System.out.println("(4) For light PRESS 4");
   System.out.println("(5) For alarm PRESS 5");
   System.out.println("(6) For exit PRESS 6");
   System.out.print("please enter the option:\n");
   try
   {
   int m=new Scanner(System.in).nextInt();
   
   switch(m)
   {
     case 1:liftArrive();
	       break;
	 case 2:destination();
	       break;
	 case 3:fan();
	       break;
	 case 4:light();
	       break;
	 case 5:alarm();
	       break;
	 case 6:exit();
	        break;
	 default: System.out.println("please select a valid option");
	          menu();
			  break;
	}
	}catch(InputMismatchException e)
    {
	  System.out.println("please enter a valid number");
	  menu();
	}
  }
  public void liftArrive()
  {
    Random rand = new Random();
    int floor = rand.nextInt(10);
    System.out.print("enter the level in which you are:");
	try{
	 int choice=new Scanner(System.in).nextInt();
    if(floor==choice)
	 {
	   doorOpen();
	   doorClose();
	  }
	  else if(floor>choice)
	  {
	   liftDown();
	   }
	  else if(floor<choice)
	  {
	   liftUp();
	   }
	 }catch(Exception e)
	 {
	  System.out.println("please enter proper data");
	  liftArrive();
	 }
	  destination();
  }
  
  public void destination()
  {
    int limit=15;
	Random rand = new Random();
    int floor = rand.nextInt(10);
	System.out.println("enter number of persons");
	int n=new Scanner(System.in).nextInt();
	if(n<=limit)
	{
	 System.out.print("enter the destination level:");
	 int choice=new Scanner(System.in).nextInt();
	 if(floor==choice)
	 {
	   doorOpen();
	   doorClose();
	  }
	  else if(floor>choice)
	  {
	   liftDown();
	   }
	  else if(floor<choice)
	  {
	   liftUp();
	   }

	 }
	 else
	 {
	  overLoad();
	  }
	  menuMain();
  }

  public void liftUp()
  {
  try{
  System.out.println("Lift is moving up to your floor.....");
  Thread.sleep(3000);
   }catch(Exception e){}
  System.out.println("Lift Arrived");
  doorOpen();
  doorClose();
  }
  
  public void liftDown()
  {
  try{
  System.out.println("Lift is coming down to your way......");
  Thread.sleep(3000);
   }catch(Exception e){}
  System.out.println("Lift Arrived");
  doorOpen();
  doorClose();
  }
  
  public void doorOpen()
  {
  try{
   System.out.println("door opening.....");
   Thread.sleep(2500);
   }catch(Exception e){}
  }
  
  public void doorClose()
  {
  try{
   System.out.println("door closing.....");
   Thread.sleep(2500);
   }catch(Exception e){}
  }
  
  public void overLoad()
  {
  try{
  System.out.println("OVERLOAD");
  Thread.sleep(2500);
   }catch(Exception e){}
   destination();
  }
  
  public void fan()
  {
  try{
   System.out.println("PRESS 1 to switch ON fan, otherwise 0");
   int f=new Scanner(System.in).nextInt();
   switch(f)
   { 
     case 0:System.out.println("Fan OFF");
	        break;
	 case 1:System.out.println("Fan ON");
	        break;
     default :System.out.println("please enter valid data");
	         fan();
	        break;
	}
	}
	catch(Exception e)
	 {
	  System.out.println("please enter proper data");
	  fan();
	 }
	menuMain();
  }
  
  public void light()
  {
  try{
   System.out.println("PRESS 1 to switch ON light, otherwise 0");
   int l=new Scanner(System.in).nextInt();
   switch(l)
   { 
     case 0:System.out.println("Light OFF");
	        break;
	 case 1:System.out.println("Light ON");
	        break;
     default :System.out.println("please enter valid data");
	         light();
	        break;
	}
	}
	catch(Exception e)
	 {
	  System.out.println("please enter proper data");
	  light();
	 }
	menuMain();
  }
  
  public void alarm()
  {
   try{
    System.out.println("sound alarm...................................");
	Thread.sleep(2500);
   }catch(Exception e){}
   System.out.println("you reached to ground floor");
   menuMain();
  }
  
  public void menuMain()
  {
    System.out.println("press * for menu");
    String c=new Scanner(System.in).next();
    switch(c)
	{
	  case "*":menu();
	         break;
	  default :System.out.println("enter proper data");
	           menuMain();
	           break;
	}
  }
  
  public void exit()
  {
   System.out.println("You are exited");
  }
 }