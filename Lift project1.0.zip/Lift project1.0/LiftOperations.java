interface LiftOperations
{
  public void menu();

  public void destination();

  public void liftUp();
  
  public void liftDown();
  
  public void doorOpen();
  
  public void doorClose();
  
  public void overLoad();
  
  public void fan();
  
  public void light();
  
  public void alarm();
  
  public void menuMain();
  
  public void exit();
  
  public void liftArrive();
  
}