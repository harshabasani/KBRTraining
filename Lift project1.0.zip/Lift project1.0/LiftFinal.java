class LiftFinal extends Lift
{
 public static void main(String[] ar)
 {
   LiftFinal f=new LiftFinal();
   f.menu();
  }
 }