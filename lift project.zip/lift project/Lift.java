import java.lang.*;
import java.util.*;
abstract class Lift implements LiftOperations 
{
static int stair=0;
static int choice;
int button;

public boolean opening()
{

    System.out.println("Doors Opening");
    return true;
 }

public boolean closing()
{
   System.out.println("Doors Closing");
   return true;
}

public void light()
{
System.out.println("To switch ON press 0,switch OFF press 1");
Scanner s=new Scanner(System.in);
System.out.print("Enter the value:");
button=s.nextInt();

   if(button==0)
    {
      System.out.println("Light ON");
    
    }
    else if(button==1)
    {
    System.out.println("Light OFF");
    }
    else
    {
      System.out.println("Please select proper option");
    }
	menu();
}

public void fan()
{ 
   System.out.println("To switch ON press 0,switch OFF press 1");
   Scanner s=new Scanner(System.in);
   System.out.print("Enter the value:");
   button=s.nextInt();
   if(button==0)
    {
      System.out.println("Fan ON");
    
    }
    else if(button==1)
    {
    System.out.println("Fan OFF");
    }
    else
    {
      System.out.println("Please select proper option");
    }
	menu();
}

public void menu()
   {
   System.out.println("Menu:");
   System.out.println("1: Destination PRESS 1");  
   System.out.println("2: Lights PRESS 2");
   System.out.println("3: Fans PRESS 3");
   System.out.println("4: Alarm PRESS 4");
   System.out.println("5: Exit PRESS 5");
	System.out.print("Please enter the option:");
try{
int n=new Scanner(System.in).nextInt();
  switch(n)
{
case 1:operation();
      break;
case 2:light();
      break;
case 3:fan();
       break;
case 4:alarm();
       break;
case 5:exit();
       break;
default : System.out.println("Enter valid option");
   }
}catch(InputMismatchException e)
{
	System.out.println("wrong input");
	menu();
}
}

public void liftUp()
{
for( ;stair<=choice;stair++)
{

for(int i=1;i<=choice;i++)
    {
     System.out.println("-->");

    }
	System.out.println("Lift is on the way");
break;
}
}


public void liftDown()
{
	for( ;stair>=choice;stair--)
{
System.out.println("Lift is on the way");
break;
}
}


public void operation()
{
       System.out.print("please enter the floor you need to go:");
       choice=new Scanner(System.in).nextInt();
     if(stair==choice)
          {
           System.out.println("Lift arraived");
          }
     else if(stair>choice)
          {
           liftDown();
           opening();
           closing();
          }
     else if(stair<choice)
          {
     liftUp();
  
   opening();
    closing();
       }
	   System.out.println("please select the menu items");
      menu();
      }
	
public void alarm()
{
	System.out.println("sound alarm");
	menu();
}

public void exit()
{
	System.out.println("exited");
}
}


























