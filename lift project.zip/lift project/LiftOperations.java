interface LiftOperations
{
public boolean opening();
public boolean closing();
public void light();
public void fan();
public void menu();
public void liftUp();
public void liftDown();
public void operation();
public void alarm();
public void exit();
}



