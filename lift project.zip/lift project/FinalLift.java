class FinalLift extends Lift
{
public static void main(String[] args)
{
FinalLift fl=new FinalLift();
fl.menu();
}
}