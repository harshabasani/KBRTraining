class LiftFinal 
{
 public static void main(String[] ar)
 {
   LiftOperations o=new Lift();
   o.menu();
  }
 }